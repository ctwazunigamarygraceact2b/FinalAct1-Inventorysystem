<?php
require_once "config.php";
include "header.php";

$totalProducts = $conn->query("SELECT COUNT(*) c FROM products")->fetch_assoc()['c'];
$totalStock    = $conn->query("SELECT COALESCE(SUM(quantity),0) c FROM products")->fetch_assoc()['c'];
$totalValue    = $conn->query("SELECT COALESCE(SUM(quantity*price),0) c FROM products")->fetch_assoc()['c'];
$lowStock      = $conn->query("SELECT COUNT(*) c FROM products WHERE quantity <= 5")->fetch_assoc()['c'];
?>
<h2>Welcome, <?= e($_SESSION['username']) ?>!</h2>
<div class="cards">
  <div class="card"><h3>Total Products</h3><p><?= $totalProducts ?></p></div>
  <div class="card"><h3>Total Stock</h3><p><?= $totalStock ?></p></div>
  <div class="card"><h3>Inventory Value</h3><p>₱<?= number_format($totalValue, 2) ?></p></div>
  <div class="card"><h3>Low Stock (≤5)</h3><p><?= $lowStock ?></p></div>
</div>
<?php if ($_SESSION['role'] === 'admin'):
  $pending = $conn->query("SELECT COUNT(*) c FROM users WHERE status='pending'")->fetch_assoc()['c']; ?>
  <div class="box">Pending registrations: <strong><?= $pending ?></strong>
  <a class="btn" href="users.php">Review</a></div>
<?php endif; ?>
</div></body></html>
