<?php
require_once "config.php";
require_login();

// Save an uploaded image, return the new file name (or null)
function save_image($file) {
    if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) return null;
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) return null;
    if ($file['size'] > 2 * 1024 * 1024) return null;   // max 2MB
    if (!is_dir(__DIR__ . "/uploads")) mkdir(__DIR__ . "/uploads", 0777, true);
    $name = bin2hex(random_bytes(8)) . "." . $ext;
    move_uploaded_file($file['tmp_name'], __DIR__ . "/uploads/" . $name);
    return $name;
}

function delete_image($name) {
    if ($name && file_exists(__DIR__ . "/uploads/" . $name)) {
        unlink(__DIR__ . "/uploads/" . $name);
    }
}

// DELETE
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare("SELECT image FROM products WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    if ($row) delete_image($row['image']);

    $stmt = $conn->prepare("DELETE FROM products WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: products.php");
    exit;
}

// CREATE / UPDATE
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = trim($_POST['name']);
    $desc  = trim($_POST['description']);
    $qty   = (int)$_POST['quantity'];
    $price = (float)$_POST['price'];
    $id    = (int)($_POST['id'] ?? 0);
    $newImage = save_image($_FILES['image'] ?? null);

    if ($id > 0) {
        if ($newImage) {
            $stmt = $conn->prepare("SELECT image FROM products WHERE id=?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $old = $stmt->get_result()->fetch_assoc();
            if ($old) delete_image($old['image']);

            $stmt = $conn->prepare("UPDATE products SET name=?, description=?, quantity=?, price=?, image=? WHERE id=?");
            $stmt->bind_param("ssidsi", $name, $desc, $qty, $price, $newImage, $id);
        } else {
            $stmt = $conn->prepare("UPDATE products SET name=?, description=?, quantity=?, price=? WHERE id=?");
            $stmt->bind_param("ssidi", $name, $desc, $qty, $price, $id);
        }
    } else {
        $stmt = $conn->prepare("INSERT INTO products (name, description, quantity, price, created_by, image) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param("ssidis", $name, $desc, $qty, $price, $_SESSION['user_id'], $newImage);
    }
    $stmt->execute();
    header("Location: products.php");
    exit;
}

// EDIT (load data)
$edit = null;
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $stmt = $conn->prepare("SELECT * FROM products WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $edit = $stmt->get_result()->fetch_assoc();
}

// READ (with search)
$search = trim($_GET['q'] ?? '');
$like = "%$search%";
$stmt = $conn->prepare("SELECT p.*, u.username FROM products p LEFT JOIN users u ON p.created_by=u.id
                        WHERE p.name LIKE ? OR p.description LIKE ? ORDER BY p.id DESC");
$stmt->bind_param("ss", $like, $like);
$stmt->execute();
$products = $stmt->get_result();

include "header.php";
?>
<h2>Products</h2><br>
<div class="box">
  <h3><?= $edit ? "Edit Product" : "Add Product" ?></h3><br>
  <form method="POST" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?= $edit['id'] ?? 0 ?>">
    <label>Name</label><input type="text" name="name" required value="<?= e($edit['name'] ?? '') ?>">
    <label>Description</label><textarea name="description" rows="2"><?= e($edit['description'] ?? '') ?></textarea>
    <label>Quantity</label><input type="number" name="quantity" min="0" required value="<?= e($edit['quantity'] ?? 0) ?>">
    <label>Price</label><input type="number" name="price" step="0.01" min="0" required value="<?= e($edit['price'] ?? '') ?>">
    <label>Image (jpg, png, gif, webp — max 2MB)</label>
    <?php if (!empty($edit['image'])): ?>
      <img class="thumb" src="uploads/<?= e($edit['image']) ?>" alt=""><br><br>
    <?php endif; ?>
    <input type="file" name="image" accept="image/*">
    <button type="submit"><?= $edit ? "Update" : "Add" ?></button>
    <?php if ($edit): ?><a class="btn btn-gray" href="products.php">Cancel</a><?php endif; ?>
  </form>
</div>

<form method="GET"><input type="text" name="q" placeholder="Search product..." value="<?= e($search) ?>"></form>

<div class="table-wrap"><table>
<tr><th>ID</th><th>Image</th><th>Name</th><th>Description</th><th>Qty</th><th>Price</th><th>Added by</th><th>Updated</th><th>Action</th></tr>
<?php while ($p = $products->fetch_assoc()): ?>
<tr>
  <td><?= $p['id'] ?></td>
  <td>
    <?php if (!empty($p['image'])): ?>
      <img class="thumb" src="uploads/<?= e($p['image']) ?>" alt="<?= e($p['name']) ?>">
    <?php else: ?>
      <span style="color:#94a3b8">No image</span>
    <?php endif; ?>
  </td>
  <td><?= e($p['name']) ?></td><td><?= e($p['description']) ?></td>
  <td><?= $p['quantity'] ?></td><td>₱<?= number_format($p['price'], 2) ?></td>
  <td><?= e($p['username'] ?? '—') ?></td><td><?= $p['updated_at'] ?></td>
  <td>
    <a class="btn" href="?edit=<?= $p['id'] ?>">Edit</a>
    <a class="btn btn-red" href="?delete=<?= $p['id'] ?>" onclick="return confirm('Delete product?')">Delete</a>
  </td>
</tr>
<?php endwhile; ?>
<?php if ($products->num_rows === 0): ?>
<tr><td colspan="9" style="text-align:center;color:#64748b">No products yet.</td></tr>
<?php endif; ?>
</table></div>
</div></body></html>
