<?php
require_once "config.php";
require_admin();

if (isset($_GET['action'], $_GET['id'])) {
    $id = (int)$_GET['id'];
    if ($id !== (int)$_SESSION['user_id']) {   // admins cannot modify their own account
        if ($_GET['action'] === 'approve') {
            $conn->query("UPDATE users SET status='approved' WHERE id=$id");
        } elseif ($_GET['action'] === 'reject') {
            $conn->query("UPDATE users SET status='rejected' WHERE id=$id");
        } elseif ($_GET['action'] === 'delete') {
            $conn->query("DELETE FROM users WHERE id=$id");
        }
    }
    header("Location: users.php");
    exit;
}

include "header.php";
$users = $conn->query("SELECT * FROM users ORDER BY FIELD(status,'pending','approved','rejected'), id DESC");
?>
<h2>Users</h2><br>
<div class="table-wrap"><table>
<tr><th>ID</th><th>Username</th><th>Role</th><th>Status</th><th>Created</th><th>Action</th></tr>
<?php while ($u = $users->fetch_assoc()): ?>
<tr>
  <td><?= $u['id'] ?></td><td><?= e($u['username']) ?></td>
  <td><?= $u['role'] ?></td><td><?= $u['status'] ?></td><td><?= $u['created_at'] ?></td>
  <td>
    <?php if ($u['id'] != $_SESSION['user_id']): ?>
      <?php if ($u['status'] !== 'approved'): ?><a class="btn btn-green" href="?action=approve&id=<?= $u['id'] ?>">Approve</a><?php endif; ?>
      <?php if ($u['status'] === 'pending'): ?><a class="btn btn-gray" href="?action=reject&id=<?= $u['id'] ?>">Reject</a><?php endif; ?>
      <a class="btn btn-red" href="?action=delete&id=<?= $u['id'] ?>" onclick="return confirm('Delete user?')">Delete</a>
    <?php else: ?>—<?php endif; ?>
  </td>
</tr>
<?php endwhile; ?>
</table></div>
</div></body></html>
