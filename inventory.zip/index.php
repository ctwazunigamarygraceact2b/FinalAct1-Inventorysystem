<?php
require_once "config.php";
if (isset($_SESSION['user_id'])) { header("Location: dashboard.php"); exit; }

$error = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if (!$user || !password_verify($password, $user['password'])) {
        $error = "Invalid username or password.";
    } elseif ($user['status'] === 'pending') {
        $error = "Your account is still waiting for admin approval.";
    } elseif ($user['status'] === 'rejected') {
        $error = "Your account has been rejected.";
    } else {
        $_SESSION['user_id']  = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role']     = $user['role'];
        header("Location: dashboard.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login</title><link rel="stylesheet" href="style.css">
</head><body>
<div class="auth">
  <h2>📦 Inventory Login</h2>
  <?php if ($error): ?><div class="msg error"><?= e($error) ?></div><?php endif; ?>
  <?php if (isset($_GET['registered']) && !$error): ?><div class="msg success">Registered successfully! Please wait for admin approval.</div><?php endif; ?>
  <form method="POST">
    <label>Username</label><input type="text" name="username" required>
    <label>Password</label><input type="password" name="password" required>
    <button type="submit">Log In</button>
  </form>
  <div class="link">No account yet? <a href="register.php">Register</a></div>
</div>
</body></html>
