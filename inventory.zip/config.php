<?php
ini_set("display_errors", 1);
error_reporting(E_ALL);
session_start();
$conn = new mysqli("localhost", "root", "", "samplekk");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Auto-create a default admin if there are no users yet (admin / admin123)
$check = $conn->query("SELECT COUNT(*) AS c FROM users")->fetch_assoc();
if ($check['c'] == 0) {
    $hash = password_hash("admin123", PASSWORD_DEFAULT);
    $conn->query("INSERT INTO users (username, password, status, role)
                  VALUES ('admin', '$hash', 'approved', 'admin')");
}

function e($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

function require_login() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: index.php");
        exit;
    }
}

function require_admin() {
    require_login();
    if ($_SESSION['role'] !== 'admin') {
        header("Location: dashboard.php");
        exit;
    }
}
