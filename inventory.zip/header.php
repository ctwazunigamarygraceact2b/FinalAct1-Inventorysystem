<?php require_login(); ?>
<!DOCTYPE html>
<html><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Inventory System</title>
<link rel="stylesheet" href="style.css">
</head><body>
<nav>
  <strong>📦 Inventory</strong>
  <a href="dashboard.php">Dashboard</a>
  <a href="products.php">Products</a>
  <?php if ($_SESSION['role'] === 'admin'): ?><a href="users.php">Users</a><?php endif; ?>
  <span class="right"><?= e($_SESSION['username']) ?> (<?= e($_SESSION['role']) ?>) &nbsp;
  <a href="logout.php">Logout</a></span>
</nav>
<div class="container">
